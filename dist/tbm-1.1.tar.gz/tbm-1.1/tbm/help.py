TEXT = """
WELCOME!
TELEGRAM BOT MANAGER

COMANDS : 
    build   >>>   TO BUILD YOUR PROJECT STRUCTURE
    run     >>>   TO RUN YOUR PROJECT


run 'tgm build' then enter the required details
next enter 'cd <name>' to enter your project directory
do your code
use 'tgm run' to run your project :)
    


https://github.com/pousay/tgm
[ any contributions are welcome :) ]
"""


def help():
    print(TEXT)
